import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/model/project.dart';
import 'function/func.dart';

class NextLoginPage extends StatefulWidget {
  const NextLoginPage({super.key});

  @override
  State<NextLoginPage> createState() => _NextLoginPageState();
}

class _NextLoginPageState extends State<NextLoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Consumer<ProjectModel>(
      builder: (context, projectModel, child) {
        return Center(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                      onPressed: () {
                        showNewProjectPopup(context);
                      },
                      child: Text('New Project')),
                  TextButton(onPressed: () {showJoinPopup(context);}, child: Text('Join in'))
                ],
              ),
              SizedBox(
                width: 500,
                height: 500,
                child: ListView.builder(
                  itemCount: projectModel.projects.length + 1,
                  itemBuilder: (context, index) {
                    if (index == projectModel.projects.length){
                      return IconButton(
                        icon: Icon(Icons.add),
                        onPressed: () => showNewProjectPopup(context),
                      );
                    }
                    return ListTile(
                      title: Text(projectModel.projects[index].title.toString()),
                      subtitle:
                          Text(projectModel.projects[index].detail.toString()),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    ));
  }
}
