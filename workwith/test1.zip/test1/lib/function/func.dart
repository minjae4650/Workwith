import 'package:flutter/material.dart';
import 'package:test1/model/project.dart';
import 'package:test1/transport/new_project_trans.dart';
import 'package:provider/provider.dart';

void showNewProjectPopup(BuildContext context) {

  final titleController = TextEditingController();
  final detailController = TextEditingController();

  showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('새 프로젝트 생성'),
          content: Column(
            children: <Widget>[
              Container(
                width: 600.0,
                child: TextField(
                  controller: titleController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: ' 프로젝트 이름',
                  ),
                ),
              ),
              Container(
                width: 600.0,
                height: 600.0,
                child: TextField(
                  controller: detailController,
                  maxLines: 30,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: '프로젝트 내용을 입력하세요',
                  ),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('저장하기'),
              onPressed: () {
                NewProject newProject = NewProject(
                  title: titleController.text,
                  detail: detailController.text,
                );
                // Add the project to the project list
                Provider.of<ProjectModel>(context, listen: false).addProject(newProject);
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('추가하기'),
              onPressed: () {
                sendProjectData(titleController.text, detailController.text);
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('닫기'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      });
}

void showJoinPopup(BuildContext context) {
  final joinCodeController = TextEditingController();

  showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('참가하기'),
          content: Column(
            children: <Widget>[
              Container(
                width: 600.0,
                child: TextField(
                  controller: joinCodeController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: ' 프로젝트 코드',
                  ),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('참가하기'),
              onPressed: () {
                sendJoinCodeData(joinCodeController.text);
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('닫기'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      });
}

